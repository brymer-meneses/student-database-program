# RestaurantMgt Sample UI JavaFX

This project is purely JavaFX - it gives you a basis of what to do regarding your projects, **Note:** it is not a fully fledged system.

Dark Mode

![](https://github.com/k33ptoo/RestaurantMgtSampleUI/blob/master/imgs/sc2.PNG)

Light Mode

![](https://github.com/k33ptoo/RestaurantMgtSampleUI/blob/master/imgs/sc.PNG)
